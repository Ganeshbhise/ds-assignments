

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
        try {
            RemoteInterface remoteObject = (RemoteInterface) Naming.lookup("rmi://localhost/server");
            System.out.println("Enter first Number");
            double a = sc.nextDouble();
            System.out.println("Enter second Number");
            double b = sc.nextDouble();
            
            System.out.println("Result add is" + remoteObject.add(a, b));
            System.out.println("Result sub is" + remoteObject.sub(a, b));
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
