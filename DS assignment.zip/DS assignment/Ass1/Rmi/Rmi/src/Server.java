

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class Server {
    public static void main(String[] args) {
        try {
            // Create an instance of the server
            Serverimp server = new Serverimp();

            // Create the RMI registry and bind the server to a specific port
            Naming.rebind("server", server);

            System.out.println("Server started. Waiting for clients...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
